CREATE DATABASE IF NOT EXISTS upi_transaction_analysis;
USE upi_transaction_analysis;


CREATE TABLE customer_master (
    customer_id VARCHAR(20) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(20) NOT NULL,
    region VARCHAR(50) NOT NULL,
    date_joined DATE NOT NULL,
    is_business_user BOOLEAN NOT NULL,
    risk_score DECIMAL(5,4) NOT NULL,

    mobile_number VARCHAR(15) NOT NULL,

    PRIMARY KEY (customer_id),

    CHECK (age >= 18 AND age <= 100),
    CHECK (risk_score >= 0 AND risk_score <= 1)
);

CREATE TABLE device_info (
    device_id VARCHAR(20) NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    device_type VARCHAR(30) NOT NULL,
    app_version VARCHAR(30) NOT NULL,
    is_rooted BOOLEAN NOT NULL,
    last_active DATETIME NOT NULL,

    PRIMARY KEY (device_id),

    FOREIGN KEY (customer_id)
        REFERENCES customer_master(customer_id)
);

CREATE TABLE upi_account_details (
    upi_id VARCHAR(100) NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    bank_name VARCHAR(100) NOT NULL,
    account_type VARCHAR(30) NOT NULL,
    date_added DATE NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (upi_id),

    FOREIGN KEY (customer_id)
        REFERENCES customer_master(customer_id),

    CHECK (
        account_type IN
        ('savings', 'current', 'credit_card_linked')
    ),

    CHECK (
        status IN
        ('active', 'inactive', 'blocked', 'suspended')
    )
);

CREATE TABLE merchant_info (
    merchant_id VARCHAR(20) NOT NULL,
    merchant_name VARCHAR(200) NOT NULL,
    merchant_type VARCHAR(50) NOT NULL,
    region VARCHAR(50) NOT NULL,
    onboard_date DATE NOT NULL,
    risk_score DECIMAL(5,4) NOT NULL,

    PRIMARY KEY (merchant_id),

    CHECK (risk_score >= 0 AND risk_score <= 1)
);

CREATE TABLE upi_transaction_history (
    transaction_id VARCHAR(30) NOT NULL,
    upi_id VARCHAR(100) NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    timestamp DATETIME NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    transaction_type VARCHAR(30) NOT NULL,
    merchant_id VARCHAR(20) NULL,
    counterparty_upi VARCHAR(100) NULL,
    status VARCHAR(20) NOT NULL,
    device_id VARCHAR(20) NOT NULL,
    device_type VARCHAR(30) NOT NULL,
    channel VARCHAR(30) NOT NULL,
    fraud_flag BOOLEAN NOT NULL,
    reversal_flag BOOLEAN NOT NULL,
    failure_reason VARCHAR(100) NULL,

    PRIMARY KEY (transaction_id),

    FOREIGN KEY (upi_id)
        REFERENCES upi_account_details(upi_id),

    FOREIGN KEY (customer_id)
        REFERENCES customer_master(customer_id),

    FOREIGN KEY (merchant_id)
        REFERENCES merchant_info(merchant_id),

    FOREIGN KEY (device_id)
        REFERENCES device_info(device_id),

    CHECK (amount > 0),

    CHECK (
        transaction_type IN
        ('send', 'receive', 'merchant_payment', 'bill_pay')
    ),

    CHECK (
        status IN
        ('success', 'failed', 'pending')
    ),

    CHECK (
        device_type IN
        ('android', 'ios', 'feature_phone', 'tablet')
    ),

    CHECK (
        channel IN
        ('app', 'intent', 'qr_code')
    )
);

CREATE TABLE customer_feedback_surveys (
    feedback_id VARCHAR(30) NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    date_submitted DATE NOT NULL,
    feedback_text TEXT NOT NULL,
    satisfaction_score INT NOT NULL,
    issue_type VARCHAR(50) NOT NULL,
    resolved BOOLEAN NOT NULL,

    PRIMARY KEY (feedback_id),

    FOREIGN KEY (customer_id)
        REFERENCES customer_master(customer_id),

    CHECK (satisfaction_score BETWEEN 1 AND 5),

    CHECK (
        issue_type IN
        ('fraud', 'transaction', 'app_usability', 'other')
    )
);

CREATE TABLE fraud_alert_history (
    alert_id VARCHAR(30) NOT NULL,
    transaction_id VARCHAR(30) NOT NULL,
    alert_type VARCHAR(50) NOT NULL,
    alert_date DATETIME NOT NULL,
    resolved BOOLEAN NOT NULL,
    resolution_date DATETIME NULL,
    remarks TEXT NULL,

    PRIMARY KEY (alert_id),

    FOREIGN KEY (transaction_id)
        REFERENCES upi_transaction_history(transaction_id),

    CHECK (
        alert_type IN
        ('frequent_failure',
         'unusual_time',
         'unusual_amount',
         'suspicious_login')
    )
);
USE upi_transaction_analysis;
USE upi_transaction_analysis;

SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM upi_transaction_history;

ALTER TABLE upi_transaction_history
MODIFY fraud_flag VARCHAR(5),
MODIFY reversal_flag VARCHAR(5);

SET FOREIGN_KEY_CHECKS = 1;


SELECT COUNT(*) AS total_transactions
FROM upi_transaction_history;

SELECT *
FROM upi_transaction_history
LIMIT 1;

SELECT COUNT(*) FROM customer_master
WHERE customer_id = 'cust100901';

SELECT COUNT(*) FROM upi_account_details
WHERE upi_id = 'jeffery4732@upi';

SELECT COUNT(*) FROM merchant_info
WHERE merchant_id = 'merch1113';

SELECT device_id
FROM upi_transaction_history
WHERE transaction_id = 'txn1000002';

SELECT device_id
FROM upi_transaction_history
WHERE transaction_id = 'txn1000002';

SELECT COUNT(*)
FROM upi_account_details
WHERE upi_id = 'jeffery4732@upi';

SELECT COUNT(*)
FROM merchant_info
WHERE merchant_id = 'merch1113';


USE upi_transaction_analysis;

SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM upi_transaction_history;

ALTER TABLE upi_transaction_history
MODIFY fraud_flag VARCHAR(5),
MODIFY reversal_flag VARCHAR(5),
MODIFY device_id VARCHAR(20) NULL,
MODIFY merchant_id VARCHAR(20) NULL;

SET FOREIGN_KEY_CHECKS = 1;

SELECT transaction_id, device_id, merchant_id, upi_id, customer_id
FROM upi_transaction_history
WHERE transaction_id = 'txn1000002';

SELECT COUNT(*) AS row_count
FROM upi_transaction_history;

SELECT transaction_id, device_id, merchant_id, upi_id, customer_id
FROM upi_transaction_history
WHERE transaction_id IS NOT NULL;

SELECT COUNT(*)
FROM device_info
WHERE device_id = 'dev100901';

SHOW CREATE TABLE upi_transaction_history;

SELECT
    CONSTRAINT_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = 'upi_transaction_analysis'
  AND TABLE_NAME = 'upi_transaction_history'
  AND REFERENCED_TABLE_NAME IS NOT NULL;
  
  USE upi_transaction_analysis;

SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM upi_transaction_history;

ALTER TABLE upi_transaction_history
MODIFY fraud_flag VARCHAR(5),
MODIFY reversal_flag VARCHAR(5),
MODIFY merchant_id VARCHAR(20) NULL,
MODIFY device_id VARCHAR(20) NULL;

SET FOREIGN_KEY_CHECKS = 1;


USE upi_transaction_analysis;

SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM upi_transaction_history;

ALTER TABLE upi_transaction_history
DROP FOREIGN KEY upi_transaction_history_ibfk_1,
DROP FOREIGN KEY upi_transaction_history_ibfk_2,
DROP FOREIGN KEY upi_transaction_history_ibfk_3,
DROP FOREIGN KEY upi_transaction_history_ibfk_4;

SET FOREIGN_KEY_CHECKS = 1;



SELECT CONSTRAINT_NAME
FROM information_schema.TABLE_CONSTRAINTS
WHERE TABLE_SCHEMA = 'upi_transaction_analysis'
  AND TABLE_NAME = 'upi_transaction_history'
  AND CONSTRAINT_TYPE = 'FOREIGN KEY';
  
  USE upi_transaction_analysis;

ALTER TABLE upi_transaction_history
DROP FOREIGN KEY upi_transaction_history_ibfk_3;


USE upi_transaction_analysis;

ALTER TABLE upi_transaction_history
DROP FOREIGN KEY upi_transaction_history_ibfk_3;

USE upi_transaction_analysis;

SELECT CONSTRAINT_NAME
FROM information_schema.TABLE_CONSTRAINTS
WHERE TABLE_SCHEMA = 'upi_transaction_analysis'
  AND TABLE_NAME = 'upi_transaction_history'
  AND CONSTRAINT_TYPE = 'FOREIGN KEY';
  
  USE upi_transaction_analysis;

SELECT CONSTRAINT_NAME
FROM information_schema.TABLE_CONSTRAINTS
WHERE TABLE_SCHEMA = 'upi_transaction_analysis'
  AND TABLE_NAME = 'upi_transaction_history'
  AND CONSTRAINT_TYPE = 'FOREIGN KEY';
  
  ALTER TABLE upi_transaction_analysis.upi_transaction_history
DROP FOREIGN KEY upi_transaction_history_ibfk_3;


SELECT CONSTRAINT_NAME
FROM information_schema.TABLE_CONSTRAINTS
WHERE TABLE_SCHEMA = 'upi_transaction_analysis'
AND TABLE_NAME = 'upi_transaction_history'
AND CONSTRAINT_TYPE = 'FOREIGN KEY';

USE upi_transaction_analysis;

DELETE FROM upi_transaction_history;

DELETE FROM upi_transaction_history
WHERE transaction_id = 'txn1000002';

SELECT COUNT(*) AS row_count
FROM upi_transaction_history;

SET SQL_SAFE_UPDATES = 0;

DELETE FROM upi_transaction_history;

SET SQL_SAFE_UPDATES = 1;


SELECT COUNT(*) AS row_count
FROM upi_transaction_history;

SELECT COUNT(*) AS row_count
FROM upi_transaction_history;

SELECT COUNT(*) AS row_count
FROM upi_transaction_history;

USE upi_transaction_analysis;

SET FOREIGN_KEY_CHECKS = 0;
DELETE FROM customer_feedback_surveys;
SET FOREIGN_KEY_CHECKS = 1;

ALTER TABLE customer_feedback_surveys
MODIFY resolved VARCHAR(5);


SELECT COUNT(*) AS row_count
FROM customer_feedback_surveys;


USE upi_transaction_analysis;

SET SQL_SAFE_UPDATES = 0;

DELETE FROM customer_feedback_surveys;

SET SQL_SAFE_UPDATES = 1;

SELECT COUNT(*) AS row_count
FROM customer_feedback_surveys;

SELECT *
FROM customer_feedback_surveys
WHERE feedback_id = 'fdbk100004';

TRUNCATE TABLE customer_feedback_surveys;


SELECT COUNT(*) AS row_count
FROM customer_feedback_surveys;


TRUNCATE TABLE customer_feedback_surveys;

USE upi_transaction_analysis;

SET SQL_SAFE_UPDATES = 0;
DELETE FROM fraud_alert_history;
SET SQL_SAFE_UPDATES = 1;

ALTER TABLE fraud_alert_history
MODIFY resolved VARCHAR(5);

SELECT COUNT(*) AS row_count
FROM fraud_alert_history;

SELECT COUNT(*) AS row_count
FROM fraud_alert_history;
SELECT COUNT(*) AS total_transactions
FROM upi_transaction_history;
USE upi_transaction_analysis;

SELECT 'customer_master' AS table_name, COUNT(*) AS row_count
FROM customer_master

UNION ALL
SELECT 'device_info', COUNT(*)
FROM device_info

UNION ALL
SELECT 'upi_account_details', COUNT(*)
FROM upi_account_details

UNION ALL
SELECT 'merchant_info', COUNT(*)
FROM merchant_info

UNION ALL
SELECT 'upi_transaction_history', COUNT(*)
FROM upi_transaction_history

UNION ALL
SELECT 'fraud_alert_history', COUNT(*)
FROM fraud_alert_history

USE upi_transaction_analysis;

SHOW TABLES;
USE upi_transaction_analysis;

SHOW TABLES;

SELECT COUNT(*) AS transaction_count
FROM upi_transaction_history;



USE upi_transaction_analysis;

SELECT
    status,
    COUNT(*) AS total_transactions,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*)
         FROM upi_transaction_history), 2
    ) AS percentage
FROM upi_transaction_history
GROUP BY status
ORDER BY total_transactions DESC;